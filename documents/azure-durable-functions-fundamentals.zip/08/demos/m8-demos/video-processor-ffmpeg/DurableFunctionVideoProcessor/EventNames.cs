﻿namespace DurableFunctionVideoProcessor
{
    public static class EventNames
    {
        public const string ApprovalResult = "ApprovalResult";
    }
}