﻿namespace VideoProcessor
{
    public class VideoFileInfo
    { 
        public string Location { get; set; }
        public int BitRate { get; set; }
    }

}